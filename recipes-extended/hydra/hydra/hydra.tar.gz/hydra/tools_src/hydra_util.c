/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  Diagnostic utility for hardware anti-counterfeiting module
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../src/hydra_if.h"
#include <unistd.h>
#include "libhydra.h"

/*----------------------------------------------------------------------------*/

enum LOCK_STATE
{
    UNLOCKED,
    LOCKED,
    INVALID
};

/*----------------------------------------------------------------------------*/

static int VERBOSE = 0;

static int hydra = -1;

static unsigned char ATSHA204_SERIAL_NUMBER[ATHSHA204_SERIAL_LENGTH];
static unsigned char ATSHA204_READ_CONFIG[88];

static enum LOCK_STATE CONFIG_LOCK_STATE = INVALID;
static enum LOCK_STATE DATA_LOCK_STATE = INVALID;

/*----------------------------------------------------------------------------*/

const char* LOCK_STATE_NAME(enum LOCK_STATE state)
{
    switch (state)
    {
        case UNLOCKED :
            return "UNLOCKED";
        case LOCKED :
            return "LOCKED";
        default :
            return "INVALID";
    }
}

/*----------------------------------------------------------------------------*/

static int hydra_open(void)
{
    hydra = open(HYDRA_DEV_NAME, O_RDWR);
    if (hydra>=0)
    {
        return 1;
    } else {
        printf("Could not open security device!\n");
        return 0;
    }
}

/*----------------------------------------------------------------------------*/

static void hydra_close(void)
{
    if (hydra>=0)
    {
        close(hydra);
        hydra = -1;
    }
}

/*----------------------------------------------------------------------------*/

static int hydra_read_config(void)
{
    int i;
    hydra_rw_info_t rwi;

    for (i=0; i<22; i++) {
        rwi.zone = ZONE_CONFIG;
        rwi.byte_address = i*4;
        if (ioctl(hydra, HYDRA_IOCTL_READ_4, &rwi) != 0) {
            goto abort;
        }
        memcpy(&(ATSHA204_READ_CONFIG[i*4]), &(rwi.data[0]), 4);
    }

    return 1;

abort:
    printf("Could not read device config!\n");
    return 0;
}

/*----------------------------------------------------------------------------*/

static int hydra_authenticate(void)
{
    return hydra_isauthentic(1);
}

/*----------------------------------------------------------------------------*/

static int get_serial_number(unsigned char* serial_buffer)
{
    serial_info_t si;

    if (ioctl(hydra, HYDRA_IOCTL_GET_SERIAL, &si) != 0) {
        goto abort;
    }
    memcpy(serial_buffer, &si.data[0], ATHSHA204_SERIAL_LENGTH);

    return 1;

abort:
    printf("Could not get serial number!\n");
    return 0;
}

/*----------------------------------------------------------------------------*/

static void print_status(void)
{
    int i;
    char print_buffer[400];

    for (i=0; i<ATHSHA204_SERIAL_LENGTH; i++)
    {
        sprintf(print_buffer+i*2, "%2.2x", ATSHA204_SERIAL_NUMBER[i]);
    }
    printf("Serial number: %s\n", print_buffer);

    if (VERBOSE)
    {
        printf("Config:\n");
        for (i=0; i<88; i++)
        {
            sprintf(print_buffer+((i%8)*2), "%2.2x", ATSHA204_READ_CONFIG[i]);
            if (i%8==7) printf("  0x%2.2x: %s\n", i-7, print_buffer);
        }
    }

    printf("Config zone lock state: %s\n", LOCK_STATE_NAME(CONFIG_LOCK_STATE));
    printf("Data zone lock state: %s\n", LOCK_STATE_NAME(DATA_LOCK_STATE));

    /* Check, if authentication works */
    printf("Authentication: %s\n", (hydra_authenticate()) ? "SUCCESS" : "FAILED");
}

/*----------------------------------------------------------------------------*/

static int read_lock_state(void)
{
    /* Read the configuration */

    if (!hydra_read_config())
    {
        goto abort;
    }

    /* Check lock states */

    /* Check if config zone is unlocked */
    if (ATSHA204_READ_CONFIG[87]==0x00)
    {
        CONFIG_LOCK_STATE = LOCKED;
    } else if (ATSHA204_READ_CONFIG[87]==0x55) {
        CONFIG_LOCK_STATE = UNLOCKED;
    } else {
        CONFIG_LOCK_STATE = INVALID;
    }

    /* Check if OTP & KEYS zone is unlocked */
    if (ATSHA204_READ_CONFIG[86]==0x00)
    {
        DATA_LOCK_STATE = LOCKED;
    } else if (ATSHA204_READ_CONFIG[86]==0x55) {
        DATA_LOCK_STATE = UNLOCKED;
    } else {
        DATA_LOCK_STATE = INVALID;
    }
    return 1;

abort:
    printf("Could not read lock state!\n");
    return 0;
}

/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/

int init (void)
{
    if (!hydra_open())
    {
        goto abort;
    }

    /* Read the device serial number */

    memset(ATSHA204_SERIAL_NUMBER, 0x00, ATHSHA204_SERIAL_LENGTH);
    if (!get_serial_number(ATSHA204_SERIAL_NUMBER))
    {
        goto abort;
    }

    if (!read_lock_state())
    {
        goto abort;
    }

    return 1;

abort:
    return 0;
}


/*----------------------------------------------------------------------------*/

int main(int argc, char *argv[])
{
    int opt;
    int do_print_status = 0;

    if (argc<2) goto usage;

    while ((opt = getopt(argc, argv, "vs?h")) > 0)
    {
        switch (opt)
        {
            case 's':
                do_print_status = 1;
                break;
            case 'v':
                VERBOSE = 1;
                break;
            case '?':
            case 'h':
                goto usage;
            break;
                default:
            break;
        }
    }

        /* Initialize device */
        if (!init())
        {
            printf("Device initialization failed!\n");
        } else {
            if (do_print_status)
            {
                printf("\nSTATUS\n\n");
                print_status();
            }
        }

    hydra_close();
    return 0;

usage:
    printf("\n");
    printf("Usage: %s [-s]\n", argv[0]);
    printf("       Options:\n");
    printf("         -s: print status information\n");
    printf("         -v: verbose\n");
    printf("\n");
    return 2;
}

/*----------------------------------------------------------------------------*/
