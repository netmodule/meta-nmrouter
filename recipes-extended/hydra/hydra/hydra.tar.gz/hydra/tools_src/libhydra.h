#ifndef __LIB_HYDRA
#define __LIB_HYDRA
/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  Interface for the NetBox hardware anti hardware 
 *  counterfeiting module.
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

/*--- includes ---------------------------------------------------------------*/

/*--- defines ----------------------------------------------------------------*/

/*--- forward declarations ---------------------------------------------------*/

/*--- types ------------------------------------------------------------------*/

/*--- function prototypes ----------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

  /**
   * Checks, if the hardware is authentic
   *
   * @param     reauthenticate [input] 0=Use cached value, if available, 1=Force reauthentication
   * @return    0=Hardware is not authentic, 1=Hardware is authentic
   */
int hydra_isauthentic(int reauthenticate);

  /**
   * Returns the serial number of the security chip
   *
   * @param     pBuffer [output] Buffer of at least 9 bytes to which the 9 byte serial number is copyied
   * @return    0=Fail, 1=Success
   */
int hydra_get_serial(unsigned char* pBuffer);

#ifdef __cplusplus
}
#endif

/*----------------------------------------------------------------------------*/

#endif
