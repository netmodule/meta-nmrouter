
/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  Interface for the NetBox hardware anti hardware
 *  counterfeiting module.
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

/*--- includes ---------------------------------------------------------------*/

#include "libhydra.h"
#include "../src/hydra_if.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "sha256.h"

//#define CALCULATE_FROM_SECRET_KEYS 1

#ifdef CALCULATE_FROM_SECRET_KEYS
#include "hydra-keys.h"
#endif

/*--- defines ----------------------------------------------------------------*/

#if 0
#define HYDRA_LOG(...) printf(__VA_ARGS__)
#else
#define HYDRA_LOG(...)
#endif

/*--- forward declarations ---------------------------------------------------*/

/*--- types ------------------------------------------------------------------*/

/*--- function prototypes ----------------------------------------------------*/

/*----------------------------------------------------------------------------*/

unsigned char ATSHA204_CONFIG[16]; /* We only need the first 16 bytes
                                      so we do not read the complete 88
                                      byte config. */

/*----------------------------------------------------------------------------*/

static void print_block(unsigned char* data, int length)
{
	const int PRINT_BLOCK_SIZE = 16;
	char pbuf[PRINT_BLOCK_SIZE*4];
	int i;

	for (i=0; i<length; i++)
	{
		sprintf(pbuf+((i % PRINT_BLOCK_SIZE)*3), "%2.2x ", data[i]);
		if (((i % PRINT_BLOCK_SIZE)==(PRINT_BLOCK_SIZE-1)) || (i==length-1))
		{
			HYDRA_LOG("(%2.2d):%s\n", (i+1)-PRINT_BLOCK_SIZE, pbuf);
		}
	}
}

/*----------------------------------------------------------------------------*/

static int read_atsha_config(int hydra)
{
	unsigned int i;
	int result = 0;
	hydra_rw_info_t rwi;

	for (i=0; i<(sizeof(ATSHA204_CONFIG)/4); i++) {
		rwi.zone = ZONE_CONFIG;
		rwi.byte_address = i*4;
		if (ioctl(hydra, HYDRA_IOCTL_READ_4, &rwi) != 0) {
			result = -1;
			goto abort;
		}
		memcpy(&(ATSHA204_CONFIG[i*4]), &(rwi.data[0]), 4);
	}

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

static int atsha204_verify_with_nonce(void)
{
	int result = -1;
	int hydra = -1;
	int i;
	FILE* pF = 0;
	exclusive_lock_info_t eli;
	nonce_info_t ni;
	gendig_info_t gi;
	mac_without_key_info_t mi;

	unsigned char mac_s[32];

	unsigned char nonce[32];
	unsigned char digest[32];
	unsigned char temp[32];

	/* Build random data for nonce */
	pF = fopen("/dev/urandom", "r");
	if (fread(&ni.random_input[0], sizeof(ni.random_input), 1, pF)!=1)
	{
		HYDRA_LOG("Could not get random nonce data!");
		goto abort;
	}
	fclose(pF); pF = 0;

	hydra = open(HYDRA_DEV_NAME, O_RDONLY);
	if (hydra<0) {
		HYDRA_LOG("Could not open hydra device!");
		goto abort;
	}

	if (read_atsha_config(hydra)!=0) {
		HYDRA_LOG("Could not read atsha config!\n");
		goto abort;
	}

	/* Acquire exclusive lock */
	eli.lock = 1;
	i = 0;
	while (ioctl(hydra, HYDRA_IOCTL_EXCLUSIVE_LOCK, &eli) != 0) {
		struct timespec ts;
		i++;
		if (i>20) {
			HYDRA_LOG("Could not acquire exclusive lock!\n");
			goto abort;
		}
		ts.tv_sec = 0;
		ts.tv_nsec = 100000000;
		nanosleep(&ts, 0);
	}

	/* Build nonce data */
	if (ioctl(hydra, HYDRA_IOCTL_NONCE, &ni) != 0) {
		HYDRA_LOG("Could not build nonce!");
		goto abort;
	}

	/* Build Digest */
	gi.keyid = 0;
	if (ioctl(hydra, HYDRA_IOCTL_GENDIG, &gi) != 0)
	{
		HYDRA_LOG("Could not build digest!");
		goto abort;
	}

	/* Build MAC */
	if (ioctl(hydra, HYDRA_IOCTL_MAC_WITHOUT_KEY, &mi) != 0)
	{
		HYDRA_LOG("Could not build MAC!");
		goto abort;
	}

	/* Build software hash */
	{
#ifdef CALCULATE_FROM_SECRET_KEYS
		int k;
#endif
		SHA256_CTX sha256ctx;

		/* Calculate NONCE */
		sha256_init(&sha256ctx);

		/* Add random_h */
		sha256_update(&sha256ctx, &ni.random_out[0], 32);

		/* Add random_s */
		sha256_update(&sha256ctx, &ni.random_input[0], 20);

		/* Build remaining bytes and calculate hash */
		temp[0] = 0x16; /* Opcode */
		temp[1] = 0x01; /* Mode */
		temp[2] = 0x00; /* LSB(Mode) */

		/* Add remaining bytes */
		sha256_update(&sha256ctx, &temp[0], 3);

		sha256_final(&sha256ctx, &nonce[0]);

		/* Calculate GENDIG */
		sha256_init(&sha256ctx);

#ifdef CALCULATE_FROM_SECRET_KEYS
		/* Add secret key */
		sha256_update(&sha256ctx, &NB_KEYS[0], 32);

		/* Build remaining stuff */
		memset(&temp[0], 0x00, sizeof(temp));
		temp[0] = (unsigned char)0x15; /* Opcode for CMD_GEN_DIG */
		temp[1] = 0x02; /* Param1 (zone) */
		temp[2] = 0x00; /* Param2 (key id) */
		temp[3] = 0x00; /* Param2 */
		temp[4] = ATSHA204_CONFIG[12]; /* SN[8] */
		temp[5] = ATSHA204_CONFIG[0];  /* SN[0] */
		temp[6] = ATSHA204_CONFIG[1];  /* SN[1] */

		sha256_update(&sha256ctx, &temp[0], 32);

		for (k=0; k<8; k++) {
			HYDRA_LOG("state[%d]=0x%xUL\n", k, sha256ctx.state[k]);
		}
		HYDRA_LOG("datalen=0x%lxUL\n", sha256ctx.datalen);
		HYDRA_LOG("bitlen=0x%llxULL\n", sha256ctx.bitlen);

#else
		/* Restore precomputed SHA256 hash context state */
		sha256ctx.state[0] = 0x81be75edUL;
		sha256ctx.state[1] = 0x810483ccUL;
		sha256ctx.state[2] = 0x68991ccfUL;
		sha256ctx.state[3] = 0x380f076dUL;
		sha256ctx.state[4] = 0xb2992551UL;
		sha256ctx.state[5] = 0xe59eeb3fUL;
		sha256ctx.state[6] = 0x5135688fUL;
		sha256ctx.state[7] = 0x58bdebd1UL;
		sha256ctx.datalen = 0x0UL;
		sha256ctx.bitlen = 0x200ULL;
		memset(&(sha256ctx.data[0]), 0x00, 64);
#endif

		/* Add nonce */
		sha256_update(&sha256ctx, &nonce[0], 32);

		sha256_final(&sha256ctx, &digest[0]);

		/* Calculate MAC */
		sha256_init(&sha256ctx);

		/* Add digest */
		sha256_update(&sha256ctx, &digest[0], 32);

		/* Add digest */
		sha256_update(&sha256ctx, &digest[0], 32);

		/* Build remaining stuff */
		memset(&temp[0], 0x00, sizeof(temp));
		temp[0] = 0x08; /* Opcode */
		temp[1] = 0x43; /* Mode */
		temp[2] = 0x00; /* Keyid */
		temp[3] = 0x00; /* Fill */
		/* temp[4] - temp[14] OTP data set to 0x00 */
		temp[15] = ATSHA204_CONFIG[12]; /* SN[8] */
		temp[16] = ATSHA204_CONFIG[8];  /* SN[4] */
		temp[17] = ATSHA204_CONFIG[9];  /* SN[5] */
		temp[18] = ATSHA204_CONFIG[10]; /* SN[6] */
		temp[19] = ATSHA204_CONFIG[11]; /* SN[7] */
		temp[20] = ATSHA204_CONFIG[0];  /* SN[0] */
		temp[21] = ATSHA204_CONFIG[1];  /* SN[1] */
		temp[22] = ATSHA204_CONFIG[2];  /* SN[2] */
		temp[23] = ATSHA204_CONFIG[3];  /* SN[3] */

		sha256_update(&sha256ctx, &temp[0], 24);

		sha256_final(&sha256ctx, &mac_s[0]);

		if (memcmp(&mi.mac[0], &mac_s[0], 32)==0) {
			HYDRA_LOG("Authentication successfull\n");
			result = 0;
		} else {
			HYDRA_LOG("Authentication failed!\n");
			HYDRA_LOG("HW-MAC:");
			print_block(&mi.mac[0], 32);
			HYDRA_LOG("SW-MAC:");
			print_block(&mac_s[0], 32);
			goto abort;
		}
	}
abort:
	if (pF) {
		fclose(pF); pF = 0;
	}
	if (hydra>=0) {
		/* Release exclusive lock */
		eli.lock = 0;
		ioctl(hydra, HYDRA_IOCTL_EXCLUSIVE_LOCK, &eli);
		close(hydra);
		hydra = -1;
	}
	return result;
}

/*----------------------------------------------------------------------------*/

int hydra_isauthentic(int reauthenticate)
{
	static int CACHE_VALID = 0;
	static int CACHED_VALUE = 0;

	if ((reauthenticate) || (!CACHE_VALID)) {
		CACHED_VALUE = (atsha204_verify_with_nonce()==0) ? 1 : 0;
		CACHE_VALID = 1;
	}
	return CACHED_VALUE;
}

/*----------------------------------------------------------------------------*/

int hydra_get_serial(unsigned char* pBuffer)
{
	int result = 0;
	int hydra = -1;
	serial_info_t serial;

	hydra = open(HYDRA_DEV_NAME, O_RDONLY);
	if (hydra<0) goto abort;

	if (ioctl(hydra, HYDRA_IOCTL_GET_SERIAL, &serial)!=0) goto abort;

	memcpy(pBuffer, &(serial.data[0]), ATHSHA204_SERIAL_LENGTH);
	result = 1;

abort:
	if (hydra>=0) close(hydra);
	return result;
}

/*----------------------------------------------------------------------------*/
