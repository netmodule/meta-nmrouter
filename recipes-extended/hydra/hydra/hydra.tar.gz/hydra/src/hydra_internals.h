#ifndef __HYDRA_INTERNALS_H
#define __HYDRA_INTERNALS_H
/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  Hydra module internal definitions
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

/*--- includes ---------------------------------------------------------------*/

#include <linux/proc_fs.h>
#include "hydra_if.h"

/*--- defines ----------------------------------------------------------------*/

#define HYDRA_LOG(format, arg...) printk(KERN_ERR "HYDRA:" format "\n", ##arg)

/*--- forward declarations ---------------------------------------------------*/

/*--- types ------------------------------------------------------------------*/

/*--- function prototypes ----------------------------------------------------*/

#endif


