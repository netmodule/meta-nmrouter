#ifndef __ATSHA204_H
#define __ATSHA204_H
/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  ATSHA204 interface implementation
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

/*--- includes ---------------------------------------------------------------*/

#include "hydra_internals.h"

/*--- defines ----------------------------------------------------------------*/

/*--- forward declarations ---------------------------------------------------*/

/*--- types ------------------------------------------------------------------*/

/*--- function prototypes ----------------------------------------------------*/

int atsha204_init(void);

void atsha204_destroy(void);

int athsha204_get_status(unsigned char* config_locked, 
						unsigned char* data_locked);
int athsha204_get_serial(unsigned char* serial); /* Returns 9 byte serial number*/

int atsha204_write_4(hydra_zone_type_t zone, int byte_address, unsigned char* data);
int atsha204_read_4(hydra_zone_type_t zone, int byte_address, unsigned char* data);

int atsha204_write_32(hydra_zone_type_t zone, int byte_address, unsigned char* data);
int atsha204_read_32(hydra_zone_type_t zone, int byte_address, unsigned char* data);

int atsha204_lock_config(const unsigned char* crc);
int atsha204_lock_data(const unsigned char* crc);

int atsha204_get_random(unsigned char* data); /* Returns 32 bytes of random data */

int atsha204_nonce(unsigned char* random_input, unsigned char* random_out); /* Expects 20 bytes and returns 32 bytes of random data */
int atsha204_gendig(unsigned char keyid);
int atsha204_mac_without_key(unsigned char* mac);	/* Returns 32 byte MAC */

int atsha204_mac_with_nonce(unsigned char keyid, unsigned char* mac); /* Returns 32 byte MAC */
int atsha204_mac_without_nonce(unsigned char keyid, unsigned char* challenge, unsigned char* mac); /* Expects 32 byte challenge, returns 32 byte MAC */

int atsha204_verify_with_nonce(void);
int atsha204_verify_without_nonce(void);

int atsha204_init_chip_data_and_status(void);



/*----------------------------------------------------------------------------*/

#endif


