/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  Interface for the NetBox hardware anti hardware 
 *  counterfeiting module.
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

/*--- includes ---------------------------------------------------------------*/

#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/kernel.h>      /* printk() */
#include <linux/slab.h>        /* kmalloc() */
#include <linux/errno.h>       /* error codes */
#include <linux/cdev.h>        /* cdev_alloc */
#include <linux/device.h>      /* class_ */
#include <linux/poll.h>
#include <linux/seq_file.h>
#include <linux/proc_fs.h>
#include <asm/uaccess.h>       /* copy_to_user, copy_from_user */
#include <linux/mutex.h>
#include <linux/netbox.h>

MODULE_LICENSE("GPL");

#include "hydra_internals.h"
#include "hydra_if.h"
#include "atsha204.h"

/*--- defines ----------------------------------------------------------------*/

#define PROC_ROOT_NAME  "hydra"

#define PROC_STATUS_NAME     "status"
#define PROC_RANDOM_NAME     "random"
#define PROC_SERIAL_NAME     "serial"

/*--- static variable definition ---------------------------------------*/

struct cdev *phydra_cdev = 0;  /* allocated in hydra_driver_init_module */
static struct mutex HYDRA_MUTEX;

static dev_t hydra_dev = MKDEV(HYDRA_MAJOR_DEVICE_NUMBER, HYDRA_MINOR_DEVICE_NUMBER);
static struct class *hydra_class = 0;
static struct device *hydra_device = 0;

static struct proc_dir_entry* PROC_ROOT = 0;

static int ATSHA_FAILURE = 0;

static struct mutex EXCLUSIVE_LOCK_MUTEX;
static struct file* EXCLUSIVE_LOCK_OWNER = 0;

/*--- forward declarations ---------------------------------------------------*/

/*--- types ------------------------------------------------------------------*/

/*--- function implementation ------------------------------------------------*/

struct proc_dir_entry* GET_PROC_ROOT(void)
{
	return PROC_ROOT;
}

/*----------------------------------------------------------------------------*/

int hydra_driver_open(struct inode *pinode, struct file *pfile)
{
	return 0;
}

/*----------------------------------------------------------------------------*/

int hydra_driver_release(struct inode *pinode, struct file *pfile)
{
	if (mutex_is_locked(&EXCLUSIVE_LOCK_MUTEX)) {
		if (pfile == EXCLUSIVE_LOCK_OWNER) {
			EXCLUSIVE_LOCK_OWNER = 0;
			mutex_unlock(&EXCLUSIVE_LOCK_MUTEX);
		}
	}
	return 0;
}

/*----------------------------------------------------------------------------*/

long hydra_driver_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	int result = 0;

	mutex_lock_interruptible(&HYDRA_MUTEX);

	switch(cmd)
	{
		case HYDRA_IOCTL_READ_4:
			{
				hydra_rw_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_WRITE, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				memset(&(info.data[0]), 0x00, sizeof(info.data));
				if (atsha204_read_4(info.zone, info.byte_address, &(info.data[0])))
				{
					HYDRA_LOG("Write 4 failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_to_user((hydra_rw_info_t*) arg, &info,
					sizeof(hydra_rw_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_WRITE_4:
			{
				hydra_rw_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_write_4(info.zone, info.byte_address, &(info.data[0])))
				{
					HYDRA_LOG("Write 4 failed!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_READ_32:
			{
				hydra_rw_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_WRITE, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_read_32(info.zone, info.byte_address, &(info.data[0])))
				{
					HYDRA_LOG("Write 32 failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_to_user((hydra_rw_info_t*) arg, &info,
					sizeof(hydra_rw_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_WRITE_32:
			{
				hydra_rw_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (hydra_rw_info_t*) arg, 
					sizeof(hydra_rw_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_write_32(info.zone, info.byte_address, &(info.data[0])))
				{
					HYDRA_LOG("Write 32 failed!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_LOCK_CONFIG:
			{
				hydra_lock_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (hydra_lock_info_t*) arg, 
					sizeof(hydra_lock_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				
				if(copy_from_user(&info, (hydra_lock_info_t*) arg, 
					sizeof(hydra_lock_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_lock_config(&(info.crc[0])))
				{
					HYDRA_LOG("Config lock failed!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_LOCK_DATA:
			{
				hydra_lock_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (hydra_lock_info_t*) arg, 
					sizeof(hydra_lock_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (hydra_lock_info_t*) arg, 
					sizeof(hydra_lock_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_lock_data(&(info.crc[0])))
				{
					HYDRA_LOG("Data lock failed!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_GET_SERIAL:
			{
				serial_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_WRITE, (serial_info_t*) arg, 
					sizeof(serial_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if (athsha204_get_serial(&(info.data[0])))
				{
					HYDRA_LOG("Get serial failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_to_user((serial_info_t*) arg, &info,
					sizeof(serial_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_GET_RANDOM:
			{
				random_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_WRITE, (random_info_t*) arg, 
					sizeof(random_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_get_random(&(info.data[0])))
				{
					HYDRA_LOG("Get random failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_to_user((random_info_t*) arg, &info,
					sizeof(random_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_REINITIALIZE:
			{
				init_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_WRITE, (init_info_t*) arg, 
					sizeof(init_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}

				info.success = atsha204_init_chip_data_and_status()==0 ? 1 : 0;

				if(copy_to_user((init_info_t*) arg, &info,
					sizeof(init_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_NONCE:
			{
				nonce_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if ((!mutex_is_locked(&EXCLUSIVE_LOCK_MUTEX)) || (EXCLUSIVE_LOCK_OWNER!=filp)) {
					HYDRA_LOG("Requires exclusive lock!");
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_WRITE, (nonce_info_t*) arg, 
					sizeof(nonce_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (nonce_info_t*) arg, 
					sizeof(nonce_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (nonce_info_t*) arg, 
					sizeof(nonce_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_nonce(&info.random_input[0], &info.random_out[0])) {
					HYDRA_LOG("nonce failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_to_user((nonce_info_t*) arg, &info,
					sizeof(nonce_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_GENDIG:
			{
				gendig_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if ((!mutex_is_locked(&EXCLUSIVE_LOCK_MUTEX)) || (EXCLUSIVE_LOCK_OWNER!=filp)) {
					HYDRA_LOG("Requires exclusive lock!");
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_READ, (gendig_info_t*) arg, 
					sizeof(gendig_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (gendig_info_t*) arg, 
					sizeof(gendig_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (atsha204_gendig(info.keyid))
				{
					HYDRA_LOG("gendig failed!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_MAC_WITHOUT_KEY:
			{
				mac_without_key_info_t info;
				if (ATSHA_FAILURE)
				{
					result = -EFAULT;
					goto abort;
				}
				if ((!mutex_is_locked(&EXCLUSIVE_LOCK_MUTEX)) || (EXCLUSIVE_LOCK_OWNER!=filp)) {
					HYDRA_LOG("Requires exclusive lock!");
					result = -EFAULT;
					goto abort;
				}
				if(access_ok(VERIFY_WRITE, (mac_without_key_info_t*) arg, 
					sizeof(mac_without_key_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}

				if (atsha204_mac_without_key(&info.mac)!=0) {
					HYDRA_LOG("mac_without_key failed!");
					result = -EFAULT;
					goto abort;
				}

				if(copy_to_user((mac_without_key_info_t*) arg, &info,
					sizeof(mac_without_key_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
			}
			break;
		case HYDRA_IOCTL_EXCLUSIVE_LOCK:
			{
				exclusive_lock_info_t info;
				if(access_ok(VERIFY_READ, (exclusive_lock_info_t*) arg, 
					sizeof(exclusive_lock_info_t)) == 0)
				{
					HYDRA_LOG("Access to user space data failed!");
					result = -EFAULT;
					goto abort;
				}
				if(copy_from_user(&info, (exclusive_lock_info_t*) arg, 
					sizeof(exclusive_lock_info_t)) != 0)
				{
					HYDRA_LOG("Could not copy user data!");
					result = -EFAULT;
					goto abort;
				}
				if (info.lock) {
					if (mutex_trylock(&EXCLUSIVE_LOCK_MUTEX)) {
						EXCLUSIVE_LOCK_OWNER = filp;
					} else {
						result = -EFAULT;
						goto abort;
					}
				} else {
					if ((mutex_is_locked(&EXCLUSIVE_LOCK_MUTEX)) && (filp == EXCLUSIVE_LOCK_OWNER)) {
						EXCLUSIVE_LOCK_OWNER = 0;
						mutex_unlock(&EXCLUSIVE_LOCK_MUTEX);
					} else {
						result = -EFAULT;
						goto abort;
					}
				}
			}
			break;
		default:
			HYDRA_LOG("Invalid ioctl command!");
			result = -ENOTTY;
			goto abort;
	}

abort:
	mutex_unlock(&HYDRA_MUTEX);
	return result;
}

/*----------------------------------------------------------------------------*/

struct file_operations hydra_driver_fops =
{
	.owner = THIS_MODULE,
	.open = hydra_driver_open,
	.release = hydra_driver_release,
	.unlocked_ioctl = hydra_driver_ioctl,
};

/*----------------------------------------------------------------------------*/

static int proc_status_show(struct seq_file *m, void *v)
{
	int result = 0;
	unsigned char config_locked;
	unsigned char data_locked;

	mutex_lock_interruptible(&HYDRA_MUTEX);

	if (ATSHA_FAILURE) {
		result = -EINVAL;
		goto abort;
	}
	if (athsha204_get_status(&config_locked, &data_locked)) {
		result = -EINVAL;
		goto abort;
	}

	seq_printf(m, "Config zone:    %s\n", config_locked ? "locked" : "unlocked");
	seq_printf(m, "Data zone:      %s\n", data_locked ? "locked" : "unlocked");

abort:
	mutex_unlock(&HYDRA_MUTEX);
	return result;
}

static int proc_status_open(struct inode *inode, struct file *file) 
{
	return single_open(file, proc_status_show, PDE_DATA(inode));
}

static const struct file_operations proc_status_fops = {
	.owner = THIS_MODULE,
	.open = proc_status_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

/*----------------------------------------------------------------------------*/

static int proc_serial_show(struct seq_file *m, void *v)
{
	unsigned char serial[9];
	int ret = 0;

	mutex_lock_interruptible(&HYDRA_MUTEX);

	if (ATSHA_FAILURE) {
		memset(&serial[0], 0x00, sizeof(serial));
		ret = -EINVAL;
		goto abort;
	}
	if (athsha204_get_serial(&serial[0])) {
		memset(&serial[0], 0x00, sizeof(serial));
		ret = -EINVAL;
		goto abort;
	}

	seq_printf(m, "%2.2x%2.2x%2.2x%2.2x%2.2x%2.2x%2.2x%2.2x%2.2x\n",
			serial[0], serial[1], serial[2], serial[3], serial[4],
			serial[5], serial[6], serial[7], serial[8]);
	ret = 0;

abort:
	mutex_unlock(&HYDRA_MUTEX);
	return ret;
}

static int proc_serial_open(struct inode *inode, struct file *file) 
{
	return single_open(file, proc_serial_show, PDE_DATA(inode));
}

static const struct file_operations proc_serial_fops = {
	.owner = THIS_MODULE,
	.open = proc_serial_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

/*----------------------------------------------------------------------------*/

int proc_random_read(struct file *filp, char *buf, size_t count, loff_t *offp ) 
{
	int result = 0;
	unsigned char random[32];
	int chunk;
	int len = 0;

	mutex_lock_interruptible(&HYDRA_MUTEX);

	if (ATSHA_FAILURE) {
		result = -EINVAL;
		goto abort;
	}

	while (len<count)
	{
		if (atsha204_get_random(&random[0]))
		{
			result = -EINVAL;
			goto abort;
		}

		chunk = count-len>32 ? 32 : count-len;
		copy_to_user(buf+len, random, chunk);
		
		len += chunk;
	}

	result = len;

abort:
	mutex_unlock(&HYDRA_MUTEX);
	return result;
}

static const struct file_operations proc_random_fops = {
	.read = proc_random_read
};

/*----------------------------------------------------------------------------*/

void hydra_driver_cleanup_module(void)
{
	printk("Unloading Hydra...\n");
	
	if (hydra_class)
	{
		if (hydra_device)
		{
		  device_destroy(hydra_class, hydra_dev);
		  hydra_device = 0;
		}
		class_destroy(hydra_class);
		hydra_class = 0;
	}
	if (phydra_cdev)
	{
		cdev_del(phydra_cdev);
		phydra_cdev = 0;
	}

	unregister_chrdev_region(hydra_dev, 1);

	/* Destroy proc entries */
	if (PROC_ROOT)
	{
		remove_proc_entry(PROC_STATUS_NAME, PROC_ROOT);
		remove_proc_entry(PROC_RANDOM_NAME, PROC_ROOT);
		remove_proc_entry(PROC_SERIAL_NAME, PROC_ROOT);
		remove_proc_entry(PROC_ROOT_NAME, NULL);
		PROC_ROOT = 0;
	}

	atsha204_destroy();

	printk("Hydra unloaded\n");
}

/*----------------------------------------------------------------------------*/

int hydra_driver_init_module(void)
{
	/* Check, if we are running on a supported hardware platform */

	switch (NBHW)
	{
		default:
			/* OK */
			break;
		case 9:
			{
				int ver;
				int rev;
				if (board_decriptor_get_hw_version(0, &ver, &rev)!=0) goto abort;
				if (ver<3)
				{
					/* NBHW 09 version 1.x&2.x do not have ATSHA204 */
					ATSHA_FAILURE = 1;
				}
			}
			break;
	}

	if (!ATSHA_FAILURE)
	{
		if (atsha204_init()!=0)
		{
			HYDRA_LOG("atsha204_init failed!");
			return -ENODEV;
		}
	}

	/* Create proc entries */
	PROC_ROOT = proc_mkdir(PROC_ROOT_NAME, /* parent= */ NULL);
	if (PROC_ROOT)
	{
	} else {
		goto abort;
	}

	proc_create_data(PROC_STATUS_NAME, S_IRUGO, PROC_ROOT, &proc_status_fops, (void *)0);
	proc_create_data(PROC_SERIAL_NAME, S_IRUGO, PROC_ROOT, &proc_serial_fops, (void *)0);
	proc_create_data(PROC_RANDOM_NAME, S_IRUGO, PROC_ROOT, &proc_random_fops, (void *)0);

	/* initialize hydra mutex */
	mutex_init(&HYDRA_MUTEX);
	mutex_init(&EXCLUSIVE_LOCK_MUTEX);

	if(register_chrdev_region(hydra_dev, 1, "hydra") != 0)
	{
		HYDRA_LOG("Device number allocation for hydra driver failed");
		goto abort;
	}

	if((phydra_cdev = cdev_alloc()) == NULL)
	{
		HYDRA_LOG("Allocation of phydra_cdev failed");
		goto abort;
	}

	cdev_init(phydra_cdev, &hydra_driver_fops);

	phydra_cdev->ops = &hydra_driver_fops;
	phydra_cdev->owner = THIS_MODULE;

	if(cdev_add(phydra_cdev, hydra_dev, 1))
	{
		HYDRA_LOG("Error adding device");
		goto abort;
	}

	/* Create the required /sys entries */
	hydra_class = class_create(THIS_MODULE, "hydra");
	if (IS_ERR(hydra_class))
	{
		// ret = PTR_ERR(hydra_class);
		goto abort;
	} else {
		hydra_device = device_create(hydra_class, NULL, hydra_dev, NULL, "hydra");
	}

	printk("Hydra loaded successfully\n");

	return 0;

abort:
	HYDRA_LOG("Initialization of Hydra failed!\n");
	return -ENODEV;
}

module_init(hydra_driver_init_module);
module_exit(hydra_driver_cleanup_module);
