#ifndef __HYDRA_INTERFACE_H
#define __HYDRA_INTERFACE_H
/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  Interface for the NetBox hardware anti hardware 
 *  counterfeiting module.
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/*--- includes ---------------------------------------------------------------*/

/*--- defines ----------------------------------------------------------------*/

#define HYDRA_MAJOR_DEVICE_NUMBER 17
#define HYDRA_MINOR_DEVICE_NUMBER 0

#define ATHSHA204_SERIAL_LENGTH 9

/*--- forward declarations ---------------------------------------------------*/

/*--- types ------------------------------------------------------------------*/

typedef enum
{
	ZONE_CONFIG = 0,
	ZONE_OTP = 1,
	ZONE_DATA = 2
} hydra_zone_type_t;

typedef struct {
	hydra_zone_type_t zone;
	int byte_address;  /* Must allways be multiple of 4 */
	unsigned char data[32];
} hydra_rw_info_t;

typedef struct {
	unsigned char crc[2];
} hydra_lock_info_t;

typedef struct {
	unsigned char data[ATHSHA204_SERIAL_LENGTH];
} serial_info_t;

typedef struct {
	unsigned char data[32];
} random_info_t;

typedef struct {
	int use_cached_result; /* 0=force reauthentication using hardware, 
	                          1=return result of last authentication */
	int success;           /* 0=authentication failed, 1=authentication success */
} auth_info_t;

typedef struct {
	int success;           /* 0=initialization failed, 1=initialization success */
} init_info_t;

typedef struct {
	unsigned char random_input[20];
	unsigned char random_out[32];
} nonce_info_t;

typedef struct {
	unsigned char keyid;
} gendig_info_t;

typedef struct {
	unsigned char mac[32];
} mac_without_key_info_t;

typedef struct {
	unsigned char lock; /* 0=Release exclusive lock 1=Acquire exclusive lock */
} exclusive_lock_info_t;

#define HYDRA_IOCTL_MAGIC_CONFIG 'c'
#define HYDRA_IOCTL_MAGIC_NORMAL 'n'
#define HYDRA_IOCTL_READ_4          _IOWR(HYDRA_IOCTL_MAGIC_CONFIG,  0, hydra_rw_info_t)
#define HYDRA_IOCTL_WRITE_4         _IOW( HYDRA_IOCTL_MAGIC_CONFIG,  1, hydra_rw_info_t)
#define HYDRA_IOCTL_READ_32         _IOWR(HYDRA_IOCTL_MAGIC_CONFIG,  2, hydra_rw_info_t)
#define HYDRA_IOCTL_WRITE_32        _IOW( HYDRA_IOCTL_MAGIC_CONFIG,  3, hydra_rw_info_t)
#define HYDRA_IOCTL_LOCK_CONFIG     _IOW( HYDRA_IOCTL_MAGIC_CONFIG,  4, hydra_lock_info_t)
#define HYDRA_IOCTL_LOCK_DATA       _IOW( HYDRA_IOCTL_MAGIC_CONFIG,  5, hydra_lock_info_t)
#define HYDRA_IOCTL_GET_SERIAL      _IOR( HYDRA_IOCTL_MAGIC_NORMAL,  6, serial_info_t)
#define HYDRA_IOCTL_GET_RANDOM      _IOR( HYDRA_IOCTL_MAGIC_NORMAL,  7, random_info_t)
#define HYDRA_IOCTL_AUTHENTICATE    _IOWR(HYDRA_IOCTL_MAGIC_NORMAL,  8, auth_info_t) /* No longer supported */
#define HYDRA_IOCTL_REINITIALIZE    _IOR(HYDRA_IOCTL_MAGIC_NORMAL,   9, init_info_t)
#define HYDRA_IOCTL_NONCE           _IOR(HYDRA_IOCTL_MAGIC_NORMAL,   10, nonce_info_t)           /* Exclusive lock required */
#define HYDRA_IOCTL_GENDIG          _IOR(HYDRA_IOCTL_MAGIC_NORMAL,   11, gendig_info_t)          /* Exclusive lock required */
#define HYDRA_IOCTL_MAC_WITHOUT_KEY _IOR(HYDRA_IOCTL_MAGIC_NORMAL,   12, mac_without_key_info_t) /* Exclusive lock required */
#define HYDRA_IOCTL_EXCLUSIVE_LOCK  _IOR(HYDRA_IOCTL_MAGIC_NORMAL,   13, exclusive_lock_info_t)


#define HYDRA_DEV_NAME "/dev/hydra"

#ifdef __cplusplus
}
#endif

#endif


