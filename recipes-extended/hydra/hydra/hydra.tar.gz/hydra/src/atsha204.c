/******************************************************************************
 * (c) COPYRIGHT 2012 by NetModule AG, Switzerland.  All rights reserved.
 *
 * The program(s) may only be used and/or copied with the written permission
 * from NetModule AG or in accordance with the terms and conditions stipulated
 * in the agreement contract under which the program(s) have been supplied.
 *
 * PACKAGE : <NetBox - Hydra>
 *
 * ABSTRACT:
 *  ATSHA204 interface implementation
 *
 * HISTORY:
 *  Date      Author       Description
 *  20120403  mr           Created
 *
 *****************************************************************************/

/*--- includes ---------------------------------------------------------------*/

#include <linux/module.h>
#include <linux/i2c.h>
#include <linux/delay.h>

#include <linux/crypto.h>
#include <crypto/hash.h>
#include <crypto/algapi.h>
#include <crypto/sha.h>
#include <linux/err.h>  /* for crypto functions */
#include <linux/scatterlist.h>  /* for crypto functions */

#include "hydra_internals.h"
#include "atsha204.h"

/*--- defines ----------------------------------------------------------------*/

#define ATHSHA204_I2C_ADDRESS (0x64)

typedef enum
{
	WA_RESET        = 0x00,
	WA_SLEEP        = 0x01,
	WA_IDLE         = 0x02,
	WA_COMMAND      = 0x03
} atsha204_word_address_t;

typedef enum
{
	CMD_PAUSE        = 0x01,
	CMD_READ         = 0x02,
	CMD_MAC          = 0x08,
	CMD_HMAC         = 0x11,
	CMD_WRITE        = 0x12,
	CMD_GEN_DIG      = 0x15,
	CMD_NONCE        = 0x16,
	CMD_LOCK         = 0x17,
	CMD_RANDOM       = 0x1b,
	CMD_DERIVE_KEY   = 0x1c,
	CMD_UPDATE_EXTRA = 0x20,
	CMD_CHECK_MAC    = 0x28,
	CMD_DEV_REV      = 0x30
} atsha204_command_t;

typedef enum
{
	ST_SUCCESS       = 0x00,
	ST_CHECKMAC_FAIL = 0x01,
	ST_PARSE_ERROR   = 0x03, /* Command was properly received, but the length, command opcode, or parameters are illegal */
	ST_EXECUTE_ERROR = 0x0f, /* Command was properly received, but could not be executed by the device in its current state */
	ST_WAKE_RECEIVED = 0x11,
	ST_CRC_ERROR     = 0xff
} atsha204_status_t;

/*--- forward declarations ---------------------------------------------------*/

/*--- types ------------------------------------------------------------------*/

static const struct i2c_device_id atsha204_ids[] = {
	{ "atsha204", 0 },
	{ /* END OF LIST */ }
};
MODULE_DEVICE_TABLE(i2c, atsha204_ids);

typedef struct {
	struct i2c_adapter* adapter;
	unsigned char config[88];
} atsha204_data_t;

/*--- static variable definition ---------------------------------------------*/

static int atsha204_log = 0;
module_param(atsha204_log, int, 0);
MODULE_PARM_DESC(atsha204_log, "ATSHA204 log level");

static atsha204_data_t ATSHA204_PRIV;

/*--- function implementation ------------------------------------------------*/

static int GET_MAX_EXECUTION_TIME(atsha204_command_t cmd)
{
	switch (cmd)
	{
		case CMD_PAUSE :        return 2;
		case CMD_READ :         return 4;
		case CMD_MAC :          return 35;
		case CMD_HMAC :         return 69;
		case CMD_WRITE :        return 42;
		case CMD_GEN_DIG :      return 43;
		case CMD_NONCE :        return 60;
		case CMD_LOCK :         return 24;
		case CMD_RANDOM :       return 50;
		case CMD_DERIVE_KEY :   return 62;
		case CMD_UPDATE_EXTRA : return 12;
		case CMD_CHECK_MAC :    return 38;
		case CMD_DEV_REV :      return 2;
		default :               return 10000;
	}
}

static int GET_TYPICAL_EXECUTION_TIME(atsha204_command_t cmd)
{
	switch (cmd)
	{
		case CMD_PAUSE :        return 1;
		case CMD_READ :         return 1;
		case CMD_MAC :          return 12;
		case CMD_HMAC :         return 27;
		case CMD_WRITE :        return 4;
		case CMD_GEN_DIG :      return 11;
		case CMD_NONCE :        return 22;
		case CMD_LOCK :         return 5;
		case CMD_RANDOM :       return 11;
		case CMD_DERIVE_KEY :   return 14;
		case CMD_UPDATE_EXTRA : return 8;
		case CMD_CHECK_MAC :    return 12;
		case CMD_DEV_REV :      return 1;
		default :               return 10000;
	}
}

/*----------------------------------------------------------------------------*/

static void print_block(unsigned char* data, int length)
{
	const int PRINT_BLOCK_SIZE = 16;
	unsigned char pbuf[PRINT_BLOCK_SIZE*4];
	int i;

	for (i=0; i<length; i++)
	{
		sprintf(pbuf+((i % PRINT_BLOCK_SIZE)*3), "%2.2x ", data[i]);
		if (((i % PRINT_BLOCK_SIZE)==(PRINT_BLOCK_SIZE-1)) || (i==length-1))
		{
			msleep(50);
			HYDRA_LOG("(%2.2d):%s", (i+1)-PRINT_BLOCK_SIZE, pbuf);
		}
	}
}

/*----------------------------------------------------------------------------*/

static void calculate_crc(unsigned int length, unsigned char* data, unsigned char* crc)
{
	unsigned int counter;
	unsigned short crc_register = 0;
	unsigned short polynom = 0x8005;
	unsigned char shift_register;
	unsigned char data_bit, crc_bit;

	for (counter = 0; counter < length; counter++) {
	  for (shift_register = 0x01; shift_register > 0x00; shift_register <<= 1) {
		 data_bit = (data[counter] & shift_register) ? 1 : 0;
		 crc_bit = crc_register >> 15;

		 // Shift CRC to the left by 1.
		 crc_register <<= 1;

		 if ((data_bit ^ crc_bit) != 0)
			crc_register ^= polynom;
	  }
	}
	crc[0] = (uint8_t) (crc_register & 0x00FF);
	crc[1] = (uint8_t) (crc_register >> 8);
}

/*----------------------------------------------------------------------------*/

static int hw_wake_and_reset(void)
{
	int retries = 0;
	struct i2c_msg msg;
	int status;
	unsigned char buf[4];

	while (1)
	{
		if (atsha204_log>5) HYDRA_LOG("SEQ-WAKE");
		/* Wake device (pull SDA low for at least 60 us)*/
		memset(&msg, 0, sizeof(msg));
		memset(&buf[0], 0, sizeof(buf));
		msg.addr = ATHSHA204_I2C_ADDRESS;
		msg.buf = &buf[0];
		msg.len = 1;

		status = i2c_transfer(ATSHA204_PRIV.adapter, &msg, 1);
		if (status != 1)
		{
			if (atsha204_log>5) HYDRA_LOG("SEQ-WAKE failed. (This is normal when sleeping.)");
		}

		/* We have to wait at least 2.5ms between wake and i2c transfer */
		usleep_range(2500, 5000);

		/* Wake device (pull SDA low for at least 60 us)*/
		if (atsha204_log>5) HYDRA_LOG("SEQ-RESET");
		memset(&msg, 0, sizeof(msg));
		memset(&buf[0], 0, sizeof(buf));
		buf[0] = (unsigned char)WA_RESET;
		msg.addr = ATHSHA204_I2C_ADDRESS;
		msg.buf = &buf[0];
		msg.len = 1;

		status = i2c_transfer(ATSHA204_PRIV.adapter, &msg, 1);
		if (status != 1)
		{
			if (atsha204_log>5) HYDRA_LOG("SEQ-RESET failed! %d", status);
			if (retries<10)
			{
				retries++;
				if (atsha204_log>5) HYDRA_LOG("Retries:%d", retries);
			} else {
				HYDRA_LOG("SEQ-RESET failed due to too many retries!");
				break;
			}
		} else {
			return 0;
		}
	}

	return -1;
}

/*----------------------------------------------------------------------------*/

static int hw_idle(void)
{
	struct i2c_msg msg;
	int status;
	unsigned char buf[4];

	/* Wake device (pull SDA low for at least 60 us)*/
	if (atsha204_log>5) HYDRA_LOG("SEQ-IDLE");
	memset(&msg, 0, sizeof(msg));
	memset(&buf[0], 0, sizeof(buf));
	buf[0] = (unsigned char)WA_IDLE;
	msg.addr = ATHSHA204_I2C_ADDRESS;
	msg.buf = &buf[0];
	msg.len = 1;

	status = i2c_transfer(ATSHA204_PRIV.adapter, &msg, 1);
	if (status != 1)
	{
		HYDRA_LOG("SEQ-IDLE failed! %d", status);
		goto abort;
	}

	return 0;

abort:
	return -1;
}

/*----------------------------------------------------------------------------*/

static int hw_sleep(void)
{
	struct i2c_msg msg;
	int status;
	unsigned char buf[4];

	/* Wake device (pull SDA low for at least 60 us)*/
	if (atsha204_log>5) HYDRA_LOG("SEQ-SLEEP");
	memset(&msg, 0, sizeof(msg));
	memset(&buf[0], 0, sizeof(buf));
	buf[0] = (unsigned char)WA_SLEEP;
	msg.addr = ATHSHA204_I2C_ADDRESS;
	msg.buf = &buf[0];
	msg.len = 1;

	status = i2c_transfer(ATSHA204_PRIV.adapter, &msg, 1);
	if (status != 1)
	{
		HYDRA_LOG("SEQ-SLEEP failed! %d", status);
		goto abort;
	}

	return 0;

abort:
	return -1;
}

/*----------------------------------------------------------------------------*/

static int hw_transaction(unsigned char* buffer, int write_len, int read_len)
{
	struct i2c_msg msg;
	int status;
	unsigned char crc[2];

	if (hw_wake_and_reset()!=0) goto abort;

	/* Write request */
	if (atsha204_log>5) HYDRA_LOG("I2C-WRITE-REQ");
	msg.addr = ATHSHA204_I2C_ADDRESS;
	msg.flags = 0;
	msg.buf = buffer;
	msg.len = write_len;

	if (atsha204_log>5)
	{
		int i;
		unsigned char pbuf[200];
		for (i=0; i<write_len; i++)
			sprintf(pbuf+3*i, "%2.2x ", buffer[i]);
		HYDRA_LOG("WRITE-DATA:%s", pbuf);
	}

	status = i2c_transfer(ATSHA204_PRIV.adapter, &msg, 1);
	if (status != 1)
	{
		HYDRA_LOG("I2C-WRITE-REQ failed!");
		goto abort;
	}
	if (buffer[0]==(unsigned char)WA_COMMAND)
	{
		msleep(GET_MAX_EXECUTION_TIME((atsha204_command_t)buffer[2]));
	} else {
		msleep(GET_MAX_EXECUTION_TIME((atsha204_command_t)buffer[2]));
	}

	/* Read reponse count */
	if (atsha204_log>5) HYDRA_LOG("I2C-READ-COUNT");
	msg.addr = ATHSHA204_I2C_ADDRESS;
	msg.flags = I2C_M_RD;
	msg.buf = &buffer[0];
	msg.len = 1;

	status = i2c_transfer(ATSHA204_PRIV.adapter, &msg, 1);
	if (status != 1)
	{
		HYDRA_LOG("I2C-READ_COUNT failed!");
		goto abort;
	}
	if ((buffer[0]<=0) || (buffer[0]>read_len))
	{
		HYDRA_LOG("I2C-READ_COUNT: Invalid count %d!", buffer[0]);
		goto abort;
	}

	if (atsha204_log>5) HYDRA_LOG("I2C-READ (%d bytes)", buffer[0]);
	msg.addr = ATHSHA204_I2C_ADDRESS;
	msg.flags = I2C_M_RD;
	msg.buf = &buffer[1];
	msg.len = buffer[0]-1;

	status = i2c_transfer(ATSHA204_PRIV.adapter, &msg, 1);
	if (status != 1)
	{
		HYDRA_LOG("I2C read failed!");
		goto abort;
	}

	if (atsha204_log>5)
	{
		int i;
		unsigned char pbuf[200];
		for (i=0; i<msg.len; i++)
			sprintf(pbuf+3*i, "%2.2x ", msg.buf[i]);
		HYDRA_LOG("READ-DATA:%s", pbuf);
	}

	calculate_crc(buffer[0]-2, &buffer[0], &crc[0]);
	if (memcmp(&crc, buffer+buffer[0]-2, 2)!=0)
	{
		HYDRA_LOG("I2C-READ: Invalid response crc %2.2x%2.2x %2.2x%2.2x!", buffer[buffer[0]-2], buffer[buffer[0]-1], crc[0], crc[1]);
		goto abort;
	}

	hw_idle();

	return 0;

abort:
	hw_wake_and_reset();
	hw_idle();
	return -1;
}

/*----------------------------------------------------------------------------*/

int atsha204_write_4(hydra_zone_type_t zone, int byte_address, unsigned char* data)
{
	int result = 0;
	unsigned char buffer[12];

	if (byte_address % 4)
	{
		HYDRA_LOG("write_4 unaligned at %d!", byte_address);
		goto abort;
	}

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)sizeof(buffer)-1;
	buffer[2] = (unsigned char)CMD_WRITE;
	switch (zone)
	{
		case ZONE_CONFIG :
			buffer[3] = (unsigned char)0x00;
			break;
		case ZONE_OTP :
			buffer[3] = (unsigned char)0x01;
			break;
		case ZONE_DATA :
			buffer[3] = (unsigned char)0x02;
			break;
	}
	buffer[4] = (unsigned char)(byte_address >> 2);
	buffer[5] = 0;
	memcpy(&buffer[6], data, 4);

	calculate_crc(&buffer[10]-&buffer[1], &buffer[1], &buffer[10]);

	if (hw_transaction(&buffer[0], sizeof(buffer), sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("write_4 transaction failed!");
		goto abort;
	}

	if (buffer[1]!=ST_SUCCESS)
	{
		HYDRA_LOG("write_4 failed! Address:%d Status:%d", byte_address, buffer[1]);
	}

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_read_4(hydra_zone_type_t zone, int byte_address, unsigned char* data)
{
	int result = 0;
	unsigned char buffer[12];

	if (byte_address % 4)
	{
		HYDRA_LOG("read_4 unaligned at %d!", byte_address);
		goto abort;
	}

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)7;
	buffer[2] = (unsigned char)CMD_READ;
	switch (zone)
	{
		case ZONE_CONFIG :
			buffer[3] = (unsigned char)0x00;
			break;
		case ZONE_OTP :
			buffer[3] = (unsigned char)0x01;
			break;
		case ZONE_DATA :
			buffer[3] = (unsigned char)0x02;
			break;
	}
	buffer[4] = (unsigned char)(byte_address >> 2);
	buffer[5] = 0;

	calculate_crc(&buffer[6]-&buffer[1], &buffer[1], &buffer[6]);

	if (hw_transaction(&buffer[0], 8, sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("read_4 transaction failed!");
		goto abort;
	}

	memcpy(data, &buffer[1], 4);

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_write_32(hydra_zone_type_t zone, int byte_address, unsigned char* data)
{
	int result = 0;
	unsigned char buffer[40];

	if (byte_address % 4)
	{
		HYDRA_LOG("write_32 unaligned at %d!", byte_address);
		goto abort;
	}

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)sizeof(buffer)-1;
	buffer[2] = (unsigned char)CMD_WRITE;
	switch (zone)
	{
		case ZONE_CONFIG :
			buffer[3] = (unsigned char)0x80;
			break;
		case ZONE_OTP :
			buffer[3] = (unsigned char)0x81;
			break;
		case ZONE_DATA :
			buffer[3] = (unsigned char)0x82;
			break;
	}
	buffer[4] = (unsigned char)(byte_address >> 2);
	buffer[5] = 0;
	memcpy(&buffer[6], data, 32);

	calculate_crc(&buffer[38]-&buffer[1], &buffer[1], &buffer[38]);

	if (hw_transaction(&buffer[0], sizeof(buffer), sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("write_32 transaction failed!");
		goto abort;
	}

	if (buffer[1]!=ST_SUCCESS)
	{
		HYDRA_LOG("write_32 failed! Address:%d Status:%d", byte_address, buffer[1]);
	}

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_read_32(hydra_zone_type_t zone, int byte_address, unsigned char* data)
{
	int result = 0;
	unsigned char buffer[40];

	if (byte_address % 4)
	{
		HYDRA_LOG("read_32 unaligned at %d!", byte_address);
		goto abort;
	}

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)7;
	buffer[2] = (unsigned char)CMD_READ;
	switch (zone)
	{
		case ZONE_CONFIG :
			buffer[3] = (unsigned char)0x80;
			break;
		case ZONE_OTP :
			buffer[3] = (unsigned char)0x81;
			break;
		case ZONE_DATA :
			buffer[3] = (unsigned char)0x82;
			break;
	}
	buffer[4] = (unsigned char)(byte_address >> 2);
	buffer[5] = 0;

	calculate_crc(&buffer[6]-&buffer[1], &buffer[1], &buffer[6]);

	if (hw_transaction(&buffer[0], 8, sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("read_32 transaction failed!");
		goto abort;
	}

	memcpy(data, &buffer[1], 32);

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_lock_config(const unsigned char* crc)
{
	int result = 0;
	unsigned char buffer[8];

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)sizeof(buffer)-1;
	buffer[2] = (unsigned char)CMD_LOCK;
	buffer[3] = (unsigned char)0x00;
	buffer[4] = crc[0];
	buffer[5] = crc[1];

	calculate_crc(&buffer[6]-&buffer[1], &buffer[1], &buffer[6]);

	if (hw_transaction(&buffer[0], sizeof(buffer), sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("lock_config transaction failed!");
		goto abort;
	}

	if (buffer[1]!=ST_SUCCESS)
	{
		HYDRA_LOG("lock_config failed! Status:%d!", buffer[1]);
	}

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_lock_data(const unsigned char* crc)
{
	int result = 0;
	unsigned char buffer[8];

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)sizeof(buffer)-1;
	buffer[2] = (unsigned char)CMD_LOCK;
	buffer[3] = (unsigned char)0x01;
	buffer[4] = crc[0];
	buffer[5] = crc[1];

	calculate_crc(&buffer[6]-&buffer[1], &buffer[1], &buffer[6]);

	if (hw_transaction(&buffer[0], sizeof(buffer), sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("lock_data transaction failed!");
		goto abort;
	}

	if (buffer[1]!=ST_SUCCESS)
	{
		HYDRA_LOG("lock_data failed! Status:%d!", buffer[1]);
	}

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_get_random(unsigned char* data) /* Returns 32 bytes of random data */
{
	int result = 0;
	unsigned char buffer[40];

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)7;
	buffer[2] = (unsigned char)CMD_RANDOM;
	buffer[3] = (unsigned char)0x01; /* Do not update EEPROM */
	buffer[4] = 0;
	buffer[5] = 0;

	calculate_crc(&buffer[6]-&buffer[1], &buffer[1], &buffer[6]);

	if (hw_transaction(&buffer[0], 8, sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("get_random transaction failed!");
		goto abort;
	}

	memcpy(data, &buffer[1], 32);

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_nonce(unsigned char* random_input, unsigned char* random_out) /* Expects 20 bytes and returns 32 bytes of random data */
{
	int result = 0;
	unsigned char buffer[35];

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)27;
	buffer[2] = (unsigned char)CMD_NONCE;
	buffer[3] = (unsigned char)0x01; /* Combine random/input and do not update EEPROM */
	buffer[4] = 0;
	buffer[5] = 0;

	memcpy(&buffer[6], random_input, 20);

	calculate_crc(&buffer[26]-&buffer[1], &buffer[1], &buffer[26]);

	if (hw_transaction(&buffer[0], 28, sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("nonce transaction failed!");
		goto abort;
	}

	memcpy(random_out, &buffer[1], 32);

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_mac_without_nonce(unsigned char keyid, unsigned char* challenge, unsigned char* mac) /* Expects 32 byte challenge, returns 32 byte MAC */
{
	int result = 0;
	unsigned char buffer[40];

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)39;
	buffer[2] = (unsigned char)CMD_MAC;
	buffer[3] = (unsigned char)0x40;
	buffer[4] = keyid;
	buffer[5] = 0;

	memcpy(&buffer[6], challenge, 32);

	calculate_crc(&buffer[38]-&buffer[1], &buffer[1], &buffer[38]);

	if (hw_transaction(&buffer[0], sizeof(buffer), sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("mac transaction failed!");
		goto abort;
	}

	memcpy(mac, &buffer[1], 32);

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_mac_without_key(unsigned char* mac) /* Returns 32 byte MAC */
{
	int result = 0;
	unsigned char buffer[35];

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)7;
	buffer[2] = (unsigned char)CMD_MAC;
	buffer[3] = (unsigned char)0x43;
	buffer[4] = 0;
	buffer[5] = 0;

	calculate_crc(&buffer[6]-&buffer[1], &buffer[1], &buffer[6]);

	if (hw_transaction(&buffer[0], 8, sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("mac transaction failed!");
		goto abort;
	}

	memcpy(mac, &buffer[1], 32);

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_gendig(unsigned char keyid)
{
	int result = 0;
	unsigned char buffer[8];

	buffer[0] = (unsigned char)WA_COMMAND;
	buffer[1] = (unsigned char)sizeof(buffer)-1;
	buffer[2] = (unsigned char)CMD_GEN_DIG;
	buffer[3] = (unsigned char)0x02;
	buffer[4] = keyid;
	buffer[5] = 0;

	calculate_crc(&buffer[6]-&buffer[1], &buffer[1], &buffer[6]);

	if (hw_transaction(&buffer[0], sizeof(buffer), sizeof(buffer))<0)
	{
		result = -1;
		HYDRA_LOG("gendig transaction failed!");
		goto abort;
	}

	if (buffer[1]!=0)
	{
		result = -1;
		HYDRA_LOG("gendig returned error %d!", buffer[1]);
		goto abort;
	}

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

static int read_config(void)
{
	int i;
	int result = 0;

	for (i=0; i<22; i++) {
		result = atsha204_read_4(ZONE_CONFIG, i*4, &(ATSHA204_PRIV.config[i*4]));
		if (result!=0) goto abort;
	}

	return 0;

abort:
	HYDRA_LOG("Could not read device config!");
	return result;
}

/*----------------------------------------------------------------------------*/

int athsha204_get_status(unsigned char* config_locked,
						unsigned char* data_locked)
{
	*config_locked = ATSHA204_PRIV.config[87]==0x00;
	*data_locked = ATSHA204_PRIV.config[86]==0x00;

	return 0;
}

/*----------------------------------------------------------------------------*/

int athsha204_get_serial(unsigned char* serial) /* Returns 9 byte serial number*/
{
	serial[0] = ATSHA204_PRIV.config[0];  /* SN[0] */
	serial[1] = ATSHA204_PRIV.config[1];  /* SN[1] */
	serial[2] = ATSHA204_PRIV.config[2];  /* SN[2] */
	serial[3] = ATSHA204_PRIV.config[3];  /* SN[3] */
	serial[4] = ATSHA204_PRIV.config[8];  /* SN[4] */
	serial[5] = ATSHA204_PRIV.config[9];  /* SN[5] */
	serial[6] = ATSHA204_PRIV.config[10]; /* SN[6] */
	serial[7] = ATSHA204_PRIV.config[11]; /* SN[7] */
	serial[8] = ATSHA204_PRIV.config[12]; /* SN[8] */

	return 0;
}

/*----------------------------------------------------------------------------*/

int atsha204_init_chip_data_and_status(void)
{
	int result = 0;

	memset(&ATSHA204_PRIV.config, 0x00, sizeof(ATSHA204_PRIV.config));

	if (read_config()!=0)
	{
		HYDRA_LOG("Could not read device configuration!");
		result = -1;
		goto abort;
	}

	/* Make sure the fixed serial number bits have the expected value
	   -> Otherwise the gendig command with precalculated hash fails */
	if ((ATSHA204_PRIV.config[0] != 0x01) || /* SN[0] */
		(ATSHA204_PRIV.config[1] != 0x23) || /* SN[1] */
		(ATSHA204_PRIV.config[12] != 0xee))  /* SN[8] */
	{
		HYDRA_LOG("Invalid fixed part of serial number SN[0]=%x, SN[1]=%x, SN[8]=%x!",
					ATSHA204_PRIV.config[0],
					ATSHA204_PRIV.config[1],
					ATSHA204_PRIV.config[12]);
		result = -1;
		goto abort;
	}

	return result;

abort:
	ATSHA204_PRIV.config[87] = 0xff;
	ATSHA204_PRIV.config[86] = 0xff;
	return result;
}

/*----------------------------------------------------------------------------*/

int atsha204_init(void)
{
	int result = 0;
	memset(&ATSHA204_PRIV, 0x00, sizeof(ATSHA204_PRIV));

	ATSHA204_PRIV.adapter = i2c_get_adapter(0);

	if (ATSHA204_PRIV.adapter==0)
	{
		HYDRA_LOG("No I2C bus found!");
		result = -1;
		goto abort;
	}

	atsha204_init_chip_data_and_status();

abort:
	return result;
}

/*----------------------------------------------------------------------------*/

void atsha204_destroy(void)
{
}

/*----------------------------------------------------------------------------*/
